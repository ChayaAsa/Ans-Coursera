function success = IKinBodyIterates(Blist, M, T, thetalist0, eomg, ev)

thetalist = thetalist0;
i = 0;
maxiterations = 99;
Vb = se3ToVec(MatrixLog6(TransInv(FKinBody(M, Blist, thetalist)) * T));
err = norm(Vb(1: 3)) > eomg || norm(Vb(4: 6)) > ev;
% initial guess 
fprintf('Iteration %d :\n\n', i)
disp('Joint vector :')
% printing joint vector values
disp(thetalist')
fprintf('SE(3) end?effector config: \n')
%Displaying present Transformation matrix
disp(FKinBody(M, Blist, thetalist))
fprintf('\n error twist V_b:\n')
% Displaying Vb
fprintf('%g,%g,%g,%g,%g,%g \n\n', Vb(1),Vb(2),Vb(3),Vb(4),Vb(5),Vb(6))
fprintf('angular error magnitude ||omega_b||: %g \n',eomg)
fprintf ('linear error magnitude ||v_b||: %g \n\n',ev)
%Initializing vector matrix
finalmatx = [];
%Adding rows on each iteration
finalmatx = [finalmatx , thetalist'];


while err && i < maxiterations
    thetalist = thetalist + pinv(JacobianBody(Blist, thetalist)) * Vb;
    i = i + 1;
    Vb = se3ToVec(MatrixLog6(TransInv(FKinBody(M, Blist, thetalist)) * T));
    err = norm(Vb(1: 3)) > eomg || norm(Vb(4: 6)) > ev;
    fprintf('Iteration %d :\n\n' , i)
    disp('Joint vector :')
    disp(thetalist')

    fprintf('SE(3) end?effector config: \n')
    disp(FKinBody(M, Blist, thetalist))
    fprintf('\n error twist V_b:\n')
    fprintf('%g,%g,%g,%g,%g,%g \n\n', Vb(1),Vb(2),Vb(3),Vb(4),Vb(5),Vb(6))
    fprintf('angular error magnitude ||omega_b||: %g \n',eomg)
    fprintf ('linear error magnitude ||v_b||: %g \n\n',ev)
    finalmatx = [finalmatx ; thetalist'];
end
success = ~ err;
%creating the csv file
csvwrite('iterates.csv',finalmatx)
end
